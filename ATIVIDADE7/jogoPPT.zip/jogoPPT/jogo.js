  var escolha = prompt("Escolha uma opcao entre pedra, papel ou tesoura");

  while (escolha !== "pedra" && escolha !== "papel" && escolha !== "tesoura") {
    alert("Opção inválida, po favo, escolha pedra, papel ou tesoura");
    escolha = prompt("Escolha uma opção entre pedra, papel ou tesoura");
  }

  var escolhaComputador = Math.floor(Math.random() * 3);

  if (escolhaComputador === 0) {
    escolhaComputador = "pedra";
  } else if (escolhaComputador === 1) {
    escolhaComputador = "papel";
  } else {
    escolhaComputador = "tesoura";
  }

  alert("O computador escolheu " + escolhaComputador);

  if (escolha == escolhaComputador) {
    alert("Empate! Ambos escolheram " + escolha);
  } else if (escolha === "Pedra" && escolhaComputador === "Tesoura") {
         alert("Voce venceu! " + escolha + " vence de " + escolhaComputador)
    } else if (escolha === "Papel" && escolhaComputador === "Pedra") {
         alert("Voce venceu! " + escolha + " vence de " + escolhaComputador)
    } else if (escolha === "Tesoura" && escolhaComputador === "Papel") {
         alert("Voce venceu! " + escolha + " vence de " + escolhaComputador)
    (escolha === "Tesoura" && escolhaComputador === "Papel")
   } else {
    alert("Voce perdeu! " + escolhaComputador + " vence de " + escolha);
  }