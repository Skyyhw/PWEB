let num1 = parseFloat(prompt("Digite o primeiro número:")); 
let num2 = parseFloat(prompt("Digite o segundo número:")); 
let soma = num1 + num2; 
let subtracao = num1 - num2; 
let produto = num1 * num2; 
let divisao = num1 / num2;
let resto = num1 % num2; 
alert( "Resultados para " + num1 + " e " + num2 + ":\\n\\n" + "Soma: " + soma + "\\n" + "Subtração (1º pelo 2º): " + subtracao + "\\n" + "Produto: " + produto + "\\n" + "Divisão (1º pelo 2º): " + divisao + "\\n" + "Resto da divisão: " + resto );